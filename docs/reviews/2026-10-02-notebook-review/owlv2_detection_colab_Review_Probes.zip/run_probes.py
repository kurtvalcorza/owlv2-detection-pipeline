"""Review probes for tutorials/owlv2_detection_colab.ipynb (row 59, OWD-*).

Environment (labelled REDUCED SCALE, CPU only): conda env eo-notebook-test, Python 3.12.14, torch 2.13.0+cpu
(notebook pins 2.14.0), transformers 4.57.6, safetensors 0.8.0, numpy 2.5.3; no pyarrow (so the BCCD parquet
corpus is NOT read here; synthetic drawn-shape records stand in); CUDA_VISIBLE_DEVICES=-1; torch threads 4.
The package is imported from the reviewed worktree's src/ (P0 checks the notebook carries the same modules).
The model snapshot is the local clone's pre-staged weights/ directory, verified by verify_snapshot before load.
This is NOT a Colab or clean-runtime run.

Usage: python run_probes.py <worktree> <weights_dir> <out_json> [--model]
"""
from __future__ import annotations

import hashlib
import io
import json
import re
import sys
import tempfile
import time
import zipfile
from pathlib import Path

WT = Path(sys.argv[1])
WEIGHTS = Path(sys.argv[2])
OUT = Path(sys.argv[3])
RUN_MODEL = "--model" in sys.argv
# --model run A (recorded as P3a): phrases 'a red circle'/'a blue square', lr 1e-3, 1 epoch -> frozen already perfect, best epoch 0.
# --model run B (P3): opaque phrases the frozen model cannot ground, lr 1e-4, 3 epochs, so validation can select an epoch > 0.
PHRASES = ("type alpha", "type beta")
sys.path.insert(0, str(WT / "src"))
NB_PATH = WT / "tutorials/owlv2_detection_colab.ipynb"
results: dict = {"environment": {}, "probes": {}}
if OUT.exists():
    results = json.loads(OUT.read_text(encoding="utf-8"))


def save() -> None:
    OUT.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
cells = nb["cells"]
src = ["".join(c["source"]) for c in cells]

# ---------------------------------------------------------------- P0 parse/compile + carried cells == modules
import ast

p0 = {"n_cells": len(cells), "code_cells": sum(c["cell_type"] == "code" for c in cells), "compile_errors": [],
      "outputs_present": any(c.get("outputs") for c in cells if c["cell_type"] == "code"), "carried": {}}
for i, c in enumerate(cells):
    if c["cell_type"] == "code":
        try:
            ast.parse(src[i])
        except SyntaxError as exc:
            p0["compile_errors"].append((i, str(exc)))
for i, c in enumerate(cells):
    mod = c.get("metadata", {}).get("dimer", {}).get("embedded_module")
    if not mod:
        continue
    module_text = (WT / mod).read_text(encoding="utf-8").splitlines()
    cell_lines = src[i].splitlines()
    drop = [ln for ln in module_text if ln not in cell_lines]
    add = [ln for ln in cell_lines if ln not in module_text]
    p0["carried"][mod] = {"cell": i, "lines_only_in_module": drop, "lines_only_in_cell": add}
results["probes"]["P0_notebook_static"] = p0
save()

# ---------------------------------------------------------------- P1 static text checks
p1 = {}
stale = ["have not yet been recorded", "queued Kaggle Tesla T4", "on the queued clean-runtime run will measure",
         "This candidate asks", "this source-only build makes no numerical claim"]
p1["stale_candidate_text"] = {s: [i for i, t in enumerate(src) if s in t] for s in stale}
p1["status_docs"] = {f: ("Release-grade" in (WT / f).read_text(encoding="utf-8")) for f in ["STATUS.md", "README.md", "tutorials/README.md", "docs/release-verification.md"]}
p1["section9_md_promises_frozen_panel"] = "the frozen detections and the adapted detections side by side" in src[22]
p1["section9_code_panels"] = re.findall(r"panels = \[(.*)\]", src[23])
p1["byod_branch_imports_google_colab"] = "from google.colab import files" in src[13]
p1["prereq_says_kaggle_supported"] = "Google Colab or Kaggle" in src[1]
p1["byod_min_claim_cell0"] = re.findall(r"at least \w+ images", src[0])
p1["pins"] = re.findall(r"'([a-z\-]+==[0-9.]+)'", src[3])
p1["pyarrow_pinned"] = any(p.startswith("pyarrow") for p in p1["pins"])
p1["pyarrow_imported_by_carried_samples"] = "import pyarrow.parquet as pq" in src[9]
p1["cell21_asserts"] = [ln.strip() for ln in src[21].splitlines() if ln.strip().startswith("assert")]
p1["cell23_asserts"] = [ln.strip() for ln in src[23].splitlines() if ln.strip().startswith("assert")]
p1["section3_source_print_fallback"] = "getattr(pipe, 'source', 'local-snapshot')" in src[11]
p1["threshold_defined_in_section5_cell"] = "THRESHOLD = DETECTION_THRESHOLD" in src[15]
p1["experiments_text"] = [ln for ln in src[24].splitlines() if ln.startswith("**Optional experiments")]
p1["declared_spec"] = nb["metadata"]["dimer"]["notebook_spec"]
p1["infrastructure_label_present"] = any("Infrastructure" in t for t in src)
p1["how_to_use_present"] = any("How to use this notebook" in t for t in src)
results["probes"]["P1_static_text"] = p1
save()

# ---------------------------------------------------------------- P2 BYOD minimum size (no model)
from PIL import Image, ImageDraw  # noqa: E402

from owlv2_detection_pipeline.samples import load_byod_dataset, split_dataset, validate_dataset  # noqa: E402


def byod_zip(n: int, path: Path) -> Path:
    rows = ["file,prompt,x0,y0,x1,y1"]
    with zipfile.ZipFile(path, "w") as z:
        for k in range(n):
            im = Image.new("RGB", (64, 64), (k % 256, (7 * k) % 256, (13 * k) % 256))
            ImageDraw.Draw(im).rectangle([10, 10, 30 + k % 20, 40], fill=(255, 0, 0))
            buf = io.BytesIO()
            im.save(buf, format="PNG")
            z.writestr(f"img{k:03d}.png", buf.getvalue())
            rows.append(f"img{k:03d}.png,a red square,10,10,{30 + k % 20},40")
        z.writestr("boxes.csv", "\n".join(rows) + "\n")
    return path


p2 = {}
with tempfile.TemporaryDirectory() as tmp:
    for n in (8, 20, 37, 38, 49, 50):
        sizes = None
        try:
            recs = load_byod_dataset(byod_zip(n, Path(tmp) / f"b{n}.zip"))
            splits = split_dataset(recs, seed=42)
            sizes = {k: len(v) for k, v in splits.items()}
            manifests = {name: validate_dataset(part) for name, part in splits.items()}  # as cell 13 does
            p2[n] = {"split_sizes": sizes, "cell13_validation": "accepted"}
        except ValueError as exc:
            p2[n] = {"split_sizes": sizes, "cell13_validation": "rejected", "message": str(exc)}
results["probes"]["P2_byod_minimum"] = p2
save()

if not RUN_MODEL:
    sys.exit(0)

# ---------------------------------------------------------------- P3 in-place adaptation (reduced scale, CPU)
import torch  # noqa: E402

torch.set_num_threads(4)
from owlv2_detection_pipeline.pipeline import Owlv2DetectionPipeline, verify_snapshot  # noqa: E402

results["environment"] = {"python": sys.version.split()[0], "torch": torch.__version__, "cuda": torch.cuda.is_available(), "threads": torch.get_num_threads()}
t0 = time.perf_counter()
snap = verify_snapshot(WEIGHTS)
pipe = Owlv2DetectionPipeline.from_pretrained(weights_dir=WEIGHTS, device="cpu")
model = pipe._model
results["environment"]["load_seconds"] = round(time.perf_counter() - t0, 1)
results["environment"]["source_attr_present"] = hasattr(pipe, "source")


def head_state() -> dict:
    return {n: p.detach().clone() for n, p in model.named_parameters() if n.startswith(("class_head", "box_head"))}


def max_diff(a: dict, b: dict) -> float:
    return max(float((a[k] - b[k]).abs().max()) for k in a)


def shapes_record(rid: str, k: int) -> dict:
    im = Image.new("RGB", (320, 320), (128, 128, 128))
    d = ImageDraw.Draw(im)
    x = 20 + (k * 37) % 120
    d.ellipse([x, 30, x + 90, 120], fill=(220, 30, 30))
    d.rectangle([150, 160 + k % 40, 280, 280], fill=(30, 60, 220))
    return {"id": rid, "image": im, "boxes": [{"prompt": PHRASES[0], "box": [x, 30, x + 90, 120]}, {"prompt": PHRASES[1], "box": [150, 160 + k % 40, 280, 280]}]}


train = [shapes_record(f"t{k}", k) for k in range(8)]
val = [shapes_record(f"v{k}", 10 + k) for k in range(2)]
test = [shapes_record(f"s{k}", 20 + k) for k in range(2)]
prompts = sorted(PHRASES)
base = head_state()
p3 = {"scale": "8 train / 2 val / 2 test synthetic drawn-shape records, phrases %s, 3 epochs, lr 1e-4, CPU" % (PHRASES,)}
t = time.perf_counter()
frozen_test_first = pipe.evaluate(test, prompts=prompts)
p3["section6_first_run"] = {k: frozen_test_first[k] for k in ("map50", "precision", "recall", "n_predicted_boxes", "adapted")}
r1 = pipe.adapt(train, val, prompts=prompts, epochs=3, lr=1e-4, batch_size=4)
after1 = head_state()
p3["adapt1"] = {"best_epoch": r1["best_epoch"], "history_val": [h["val"] for h in r1["history"]], "heads_changed_vs_base_max_abs": max_diff(after1, base)}
results["probes"]["P3_in_place"] = p3
save()
# learner reruns Section 6 ("frozen model") after Section 7, e.g. for the THRESHOLD / SPLIT_SEED experiment or BYOD
frozen_test_rerun = pipe.evaluate(test, prompts=prompts)
p3["section6_rerun_after_adapt"] = {k: frozen_test_rerun[k] for k in ("map50", "precision", "recall", "n_predicted_boxes", "adapted")}
# learner reruns Section 7 (EPOCHS / LEARNING_RATE experiment)
r2 = pipe.adapt(train, val, prompts=prompts, epochs=3, lr=1e-4, batch_size=4)
p3["adapt2_epoch0_note"] = r2["history"][0].get("note")
p3["adapt2_epoch0_val"] = r2["history"][0]["val"]
p3["adapt1_epoch0_val_true_frozen"] = r1["history"][0]["val"]
p3["adapt2_start_equals_adapt1_result"] = r2["history"][0]["val"] == r1["history"][r1["best_epoch"]]["val"]
p3["heads_after_adapt2_vs_base_max_abs"] = max_diff(head_state(), base)
p3["seconds"] = round(time.perf_counter() - t, 1)
results["probes"]["P3_in_place"] = p3
save()
print(json.dumps(results["probes"]["P3_in_place"], indent=1, default=str))
